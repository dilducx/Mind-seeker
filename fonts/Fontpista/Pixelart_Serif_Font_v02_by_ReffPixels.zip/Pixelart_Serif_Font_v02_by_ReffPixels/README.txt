Pixel Art Serif Font by @ReffPixels (Pablo Rodriguez)
version 02___________________________________________________ 

Thanks for purchasing this font! I'm Reff Pixels. If you need anything, or if there is something wrong with your purchase please contact me through any of the following means:

- Contact methods
Email: reffpixels@gmail.com
Website: www.reffpixels.com

- Alternative Contact methods
Twitter: https://twitter.com/reffpixels
Itch.io: https://reffpixels.itch.io/
Discord: ReffPixels

___________________________________________________ 
Installation

To install the font simply execute the file called PixelSerif_16px_v02.ttf and follow the instructions in the prompt. This is a True Type Font.

A file called PixelSerif_16px_v02.otf is also provided for compatibility reasons, but this font does not include any Open Type exclusive functionality.

___________________________________________________ 
Contents

This font Contains characters corresponding to the following UNICODE sections:

Basic Latin (95)
Latin-1 Supplement (96)
Latin Extended-A (128)
Latin Extended-B (208)
IPA Extensions (96)
Latin Extended Additional (256)
Currency Symbols (33)

Total characters: (912)